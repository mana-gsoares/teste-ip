export const CAMPAIGN_TYPES = {
  ONGOING: 'ongoing',
  ONE_OFF: 'one_off',
};
