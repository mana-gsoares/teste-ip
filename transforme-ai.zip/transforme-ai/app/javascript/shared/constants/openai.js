export const OPEN_AI_OPTIONS = {
  IMPROVE_WRITING: 'improve_writing',
  FIX_SPELLING_GRAMMAR: 'fix_spelling_grammar',
  SHORTEN: 'shorten',
  EXPAND: 'expand',
  MAKE_FRIENDLY: 'make_friendly',
  MAKE_FORMAL: 'make_formal',
  SIMPLIFY: 'simplify',
  REPLY_SUGGESTION: 'reply_suggestion',
  SUMMARIZE: 'summarize',
};
