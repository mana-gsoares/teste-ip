export const CONTENT_TYPES = {
  INCOMING_EMAIL: 'incoming_email',
};
