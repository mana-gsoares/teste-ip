export const SDK_SET_BUBBLE_VISIBILITY = 'sdk-set-bubble-visibility';
