<template>
  <div class="test" />
</template>

<script>
export default {
  name: 'MockComponent',
};
</script>
