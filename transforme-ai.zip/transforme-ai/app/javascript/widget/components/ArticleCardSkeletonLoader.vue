<template>
  <div class="py-4 space-y-4 bg-white dark:bg-slate-700">
    <div class="space-y-2 animate-pulse">
      <div class="h-6 bg-slate-100 dark:bg-slate-500 rounded w-2/5" />
    </div>
    <div class="space-y-2 animate-pulse">
      <div class="h-4 bg-slate-100 dark:bg-slate-500 rounded" />
      <div class="h-4 bg-slate-100 dark:bg-slate-500 rounded" />
      <div class="h-4 bg-slate-100 dark:bg-slate-500 rounded" />
    </div>
    <div class="space-y-2 animate-pulse">
      <div class="h-4 bg-slate-100 dark:bg-slate-500 rounded w-1/5" />
    </div>
  </div>
</template>
