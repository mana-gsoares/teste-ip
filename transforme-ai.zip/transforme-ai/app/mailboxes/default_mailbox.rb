class DefaultMailbox < ApplicationMailbox
  def process; end
end
