module Integrations
  def self.table_name_prefix
    'integrations_'
  end
end
