module Kbase
  def self.table_name_prefix
    'kbase_'
  end
end
