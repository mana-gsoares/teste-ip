class ConversationPolicy < ApplicationPolicy
  def index?
    true
  end
end
